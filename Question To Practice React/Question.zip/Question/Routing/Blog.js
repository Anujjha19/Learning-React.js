import React from "react";

const Blog = () => {
  return (
    <div>
      <h1>Blog</h1>
      <p>Welcome to my website!</p>
    </div>
  );
};

export default Blog;
