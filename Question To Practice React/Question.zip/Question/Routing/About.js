import React from "react";

const About = () => {
  return (
    <div>
      <h1>About</h1>
      <p>Welcome to my website!</p>
    </div>
  );
};

export default About;
