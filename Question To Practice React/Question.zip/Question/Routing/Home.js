import React from "react";

const Home = () => {
  return (
    <div>
      <h1>Home</h1>
      <p>Welcome to my website!</p>
    </div>
  );
};

export default Home;
